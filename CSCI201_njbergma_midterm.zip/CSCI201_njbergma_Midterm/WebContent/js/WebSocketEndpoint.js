// creates a new WebSocket
var protocol = 'ws://',
	hostname = window.location.hostname,
	port     = ':8080',
	pathname = '/' + window.location.pathname.split('/')[1];
var socket = new WebSocket(protocol + hostname + port + pathname + '/ws');
var factory; // GLOBAL INSTANCE OF FACTORY!

// called when the socket is open, which then triggers other functions (this is how everything gets started)
socket.onopen = function (event) {
	// makes a GET request for the factory.txt stored on server
	readTextFile('resources/factory.txt', function (text) {
		// calls the callback that was passed into it to go back to socket.onopen()
		// anonymous
		socket.send(text);
	});
}

socket.onmessage = function (event) {
	// calls JavaScript's built-in JSON parser
	var msg = JSON.parse(event.data);
	// console.log(msg); // debug by uncommenting this
	// reads in messages action attribute
	var action = msg.action;

	if (action == 'Factory') {
		// create new Factory object (Factory.js NOT Factory.java) with message's 'factory' attribute
		factory = new Factory(msg['factory']);
	} else if (action == 'WorkerMoveToPath') {
		factory.moveWorker(msg['worker'], msg['shortestPathStack']);
	} else if (action == 'UpdateTaskBoard') {
		factory.taskBoard.printProductTable(
				msg['taskBoard'].workerTableColumnNames, 
				msg['taskBoard'].workerTableDataVector, 
				factory);
	} else if (action == 'UpdateResources') {
		factory.drawResources(msg['resources']);
	}
}

window.onresize = function () {
	if (factory) factory.onresize();
}

function readTextFile(file, callback)
{
	var xhr = new XMLHttpRequest();
	xhr.open("GET", file, true);
	xhr.onreadystatechange = function () {
		if(xhr.readyState === 4 && (xhr.status === 200 || xhr.status == 0)) {
			var allText = xhr.responseText;
			callback(allText);
		}
	}
	xhr.send(null);
}
