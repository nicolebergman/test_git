package client;

import java.io.IOException;
import java.util.Stack;

public class FactoryManagerOffice extends FactoryObject implements Runnable {
	private static final long serialVersionUID = 1L;
	
	// serialized data member
	public final int number;
	
	// references
	private transient Factory mFactory;
	private transient FactoryProduct mProductToMake;
	
	// path finding
	private FactoryNode currentNode;
	private transient FactoryNode office;
	private transient Stack<FactoryNode> mShortestPath;

	public FactoryManagerOffice(int inNumber, FactoryNode officeNode) {
		super(Constants.workerString, "worker" + Constants.png);
		// TODO Auto-generated constructor stub
		number = inNumber;
		office = officeNode;
	
	}
//	@Override
//	public void run() {
//		try {
//			// although it seems like its constant, there are conditions the worker will wait on
//			while (true) {
//				// assign to manager
//				office = mFactory.getNode("Manager Office");
//					mShortestPath = currentNode.findShortestPath(office);
//					// SEND SHORTEST PATH TO FRONT END
//					mFactory.sendWorkerMoveToManager(this, mShortestPath);
//					// all workers need to go to the Task Board in order to
//					// acquire a task
//					break; // No more tasks, end here
//			}
//		
//		} catch (IOException e) {
//			// e.printStackTrace();
//			// Expected to be interrupted when websocket connection ends
//			System.out.println("A worker has been interrupted");
//		}
//	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
		
	}
