// only method is a constructor which tkaes in data as its parameters (FactoryWorker and Stack holdng path)
package messages;

import java.util.Stack;

import client.FactoryNode;
import client.FactoryWorker;

// set data members so when message is serialized the reciever can access it
public class WorkerMoveToPathMessage extends Message {
	private static final long serialVersionUID = 1L;
	public FactoryWorker worker;
	public Stack<FactoryNode> shortestPathStack;

	public WorkerMoveToPathMessage(FactoryWorker worker, Stack<FactoryNode> shortestPath) {
		this.action = "WorkerMoveToPath";
		this.worker = worker;
		this.shortestPathStack = shortestPath;
	}
}
