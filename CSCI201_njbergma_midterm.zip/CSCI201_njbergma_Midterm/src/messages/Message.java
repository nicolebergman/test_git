// Serializable abstract class
// purpose is to hold data
package messages;

import java.io.Serializable;

public class Message implements Serializable {
	private static final long serialVersionUID = 1L;
	// identifier which will act as a key when we send message to client
	// ex. WebSocketEndpoint.js will receive this message and if action == WorkerMovevToPath. will do move the worker element
	public String action;
}
