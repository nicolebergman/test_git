package messages;

import java.util.Stack;

import client.FactoryNode;
import client.FactoryWorker;

public class WorkerMoveToManagerMessage extends Message {
	private static final long serialVersionUID = 1L;
	public FactoryWorker worker;
	public Stack<FactoryNode> shortestPathStack;
	
	// make legal for workers path to be to manager
	public WorkerMoveToManagerMessage(FactoryWorker worker, Stack<FactoryNode> shortestPath) {
		this.action = "SendToManager";
		this.worker = worker;
		this.shortestPathStack = shortestPath;
	}

}
