package servlets;

import java.io.IOException;
//
//import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import data.DataStorage;

/**
 * Servlet implementation class Entry
 */
@WebServlet("/EntryServlet")
public class EntryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EntryServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String filepath = request.getParameter("filepath");
    	DataStorage data = new DataStorage(filepath);
    	    	
    	HttpSession session = request.getSession(true);
    	session.setAttribute("filepath", filepath);
    	session.setAttribute("data", data);
    	
    	String errorMessage = data.ErrorMessage;  	
    	
    	if (errorMessage.equals("")) {
    		response.sendRedirect("startpage.jsp");
    	}
    	else {
    		session.setAttribute("ErrorMessage", errorMessage);
    		response.sendRedirect("entry_njbergma.jsp");
    	}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
