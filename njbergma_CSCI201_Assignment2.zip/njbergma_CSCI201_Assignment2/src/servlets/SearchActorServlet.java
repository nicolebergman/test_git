package servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import data.DataStorage;

/**
 * Servlet implementation class SearchActorServlet
 */
@WebServlet("/SearchActorServlet")
public class SearchActorServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchActorServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String actor = request.getParameter("actor");
		
		HttpSession session = request.getSession(true);
		
		String filepath = (String) session.getAttribute("filepath");
    	DataStorage data = new DataStorage(filepath);
   	
    	session.setAttribute("data", data);
    	session.setAttribute("actor", actor);

    	if (!actor.equals("")) {
    		response.sendRedirect("searchByActor.jsp");
     	}
    	
 
	}
    
    /**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}


}
