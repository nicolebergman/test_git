package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class GoBackMenu {
	
	
	private BufferedReader br = null;
	private Parser parser;
	private User currentUser;
	private Event usersEvent;
	
	public GoBackMenu() {
		
	}
	
	public void goBack() {
		
		try  {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			System.out.println("To go back to the login menu, please type 0");
			int trip = 0;
			while (trip == 0) {
				int action = Integer.parseInt(br.readLine());
				if (action == 0) {
					trip = 1;
//					@SuppressWarnings("unused")
//					BigMenu bm = new BigMenu(currentUser, parser);
					BigMenu bm = new BigMenu();
					bm.bigMenu(currentUser, parser, usersEvent);
//					GoBackMenu back = new GoBackMenu();
//					back.goBack();					
				}
				else {
					System.out.print("Invalid command. To go back to the login menu, please type 0\n");
		            goBack();					
					// loop menu
				}

			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(NumberFormatException e) {
            System.out.print("Invalid command. To go back to the login menu, please type 0\n");	    	  
            goBack();
        }
		
	}

}
