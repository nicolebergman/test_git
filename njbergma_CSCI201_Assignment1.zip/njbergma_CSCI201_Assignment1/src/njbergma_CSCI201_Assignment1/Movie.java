package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Movie {
	

	private BufferedReader br = null;
	
	String t, d, w, y, g, de, r;
	String filename;
	
	private Parser parser;
	private User currentUser;
	private Event usersEvent;
	
	Movie(String title, String director, String writers, String year, String genre, 
			String description, String rating) {
		t = title;
		d = director;
		w = writers;
		y = year;
		g = genre; 
		de = description;
		r = rating;
	}
	
	public void movieMenu() {
		
		System.out.println("1. Search by Actor");
		System.out.println("2. Search by Title");
		System.out.println("3. Search by Genre");
		System.out.println("4. Back to Login Menu");
		
		try {
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
				
			int trip = 0;
			while (trip == 0) {
				int action = Integer.parseInt(br.readLine());
				if (action == 1) {			// search by actor
					trip = 1;
					Parser parse = new Parser(filename);
					parse.actorSearch();
				}
				else if (action == 2) {		// search by title
					trip = 1;
					Parser parse = new Parser(filename);
					parse.titleSearch();
				}
				else if (action == 3) {		// search by genre
					trip = 1;
					Parser parse = new Parser(filename);
					parse.genreSearch();
				}
				else if (action == 4) {		// back to login menu
					trip = 1;
					BigMenu bm = new BigMenu();
					bm.bigMenu(currentUser, parser, usersEvent );			    	
				}

				else {
					System.out.println("Invalid input. Try again.\n");
					// loop menu
		            movieMenu();					
					trip = 0;
				}				
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(NumberFormatException e) {
            System.out.print("You have entered an invalid command, please try again.\n");	    	  
            movieMenu();
        }		
		
	}
	
}
