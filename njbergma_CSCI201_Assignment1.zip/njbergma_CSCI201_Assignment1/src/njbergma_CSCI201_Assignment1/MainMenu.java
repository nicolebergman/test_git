package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class MainMenu {
	
	private Parser parser;
	private User currentUser;
	private Event usersEvent;
	
	private BufferedReader br = null;
	
	public MainMenu(String filename) {
		parser = new Parser(filename);
		mainMenu();
	}
	
	public void mainMenu() {			
		
		try {
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			//  login or exit options
			System.out.print("1. Login");
		    System.out.print("\n2. Exit\n");
		    // get the action required (login or exit)
		    // in case of error, loop through 1 and 2
		  
		    int action = Integer.parseInt(br.readLine());
			if (action == 1) {
			    //  prompt for the user's name
			    System.out.print("Please enter your username\n");
			    
			    int trip = 0;
			    int count=0;
			    int count2=0;			    			    
				 while (trip == 0) {	
					 // get user input as a String		    		    	
					 String username = br.readLine();
					 if (parser.getUserMap().containsKey(username)) {
						 	
						 	trip = 1;
						 	// prompt for user's password
					    	System.out.print("Please enter your password\n");
					    	currentUser = parser.getUserMap().get(username);
					    	usersEvent = parser.getEvent().get(username);
					    	
					    	int trip2 = 0;
					    	while (trip2 == 0) {				    		
					    		// get their input as a String
						    	String password = br.readLine();
					    		if (parser.getUserMap2().containsKey(password)) {
					    			trip = 1;					    			
									BigMenu bm = new BigMenu();
									bm.bigMenu(currentUser, parser, usersEvent);	    	
						    	}
						    	else {
						    		++count;
						    		if (3-count == 0) {
							    		System.out.print("Too many attempts. System exit");						    			
						    			System.exit(1);
						    		}						    		
						    		System.out.println("Invalid password. You have " + (3-count2) + " more chances to enter a valid password.");
						    		trip = 0;
						    	}
					    	}					    	
					 }
					 else {
				    		++count2;
				    		if(3-count2 == 0) {
					    		System.out.print("Too many attempts. System exit");						    			
				    			System.exit(1);
				    		}						    		
				    		System.out.println("Invalid username. You have " + (3-count2) + " more chances to enter a valid username.");				  
					    	trip = 0;
					    }	      
			    }			    
			}
			else if (action == 2) {	 
				System.exit(1);
			}
			else {
			    	System.out.print("You have entered an invalid command, please try again.\n");
			    	mainMenu();
			}				
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}		    		    		     		    				    		    			    			    	
	}

}
