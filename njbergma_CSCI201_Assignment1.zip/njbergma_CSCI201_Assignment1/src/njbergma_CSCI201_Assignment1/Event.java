package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
//import java.util.HashMap;
//import java.util.HashSet;
import java.util.Set;

public class Event {
	
	private BufferedReader br = null;
	private Parser parser;
	private User currentUser;
	private Event usersEvent;
	
//	String user, userAction, userMovie, userRating;
//	HashMap<String, HashSet<String>> eventsByUser = new HashMap<String, HashSet<String>>();
//	
//	Event(String username, String action, String movie, String rating) {
//		user = username;
//		userAction = action;
//		userMovie = movie;
//		userRating = rating;
//	}
	
	Set<String> f2;	// feedSet	
	Set<String> f3;	// feedSet
	Set<String> f4;	// feedSet
	String user;
	
	Event(String username, Set<String> feedSet, Set<String> feedSet2, Set<String> feedSet3) {
		user = username;
		f2 = feedSet;
		f3 = feedSet2;
		f4 = feedSet3;
	}
	
	
	public void userFeed() {
		
		try {
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			// print feeders
			System.out.println("Feed: \n");				
			for (String action : f2) {					// action
				for (String movie : f3) {				// movie
					System.out.println(user + " " + action.toLowerCase() + " '" + movie + "'.");
					
					
					
//				System.out.println("\t" + s2);
				
			}
			
//				System.out.println("\t" + s2);
			}
//			for (String rating : f4) {				// rating
//				System.out.println("\t" + s2);
//			}
			
//			System.out.println("Feed: ");
//				
//				HashSet<String> eventsForUser = eventsByUser.get(user);
//				System.out.println("Feed: ");
//				for (String thisUsersEvent: eventsForUser) {
//					System.out.println(thisUsersEvent);
//				}				
//				SearchMenu menu = new SearchMenu();
//				menu.searchMenu();
			
					
			int trip = 0;
	        System.out.print("To go back to the login menu, please type 0.\n");
	        while (trip == 0) {	 
	        	int nextAction = Integer.parseInt(br.readLine());
	        	if (nextAction == 0) {
	        		trip = 1;
					BigMenu bm = new BigMenu();
					bm.bigMenu(currentUser, parser, usersEvent);			        		
	        	}
		        else {
		        	System.out.print("Invalid command. To go back to the login menu, please type 0.\n");
		        	trip = 0; 
		        } 
	        }	
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
