package njbergma_CSCI201_Assignment1;

public class Main {	
	
	public static void main (String[] args) {
		
		String filename = args[0];
		new MainMenu(filename);
	}			
}
