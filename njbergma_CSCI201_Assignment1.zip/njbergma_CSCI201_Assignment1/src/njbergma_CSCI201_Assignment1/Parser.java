package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.HashSet;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class Parser {
	
	Parser(String filename) {
		f = filename;
		myUsername = new HashMap<String, User>();
		myPassword = new HashMap<String, User>();
		userEvent = new HashMap<String, Event>();
		parseUsers();
		parseMovies();
	}
	
	private BufferedReader br = null;
	
	// user parsing
	private HashMap<String, User> myUsername;	// <username, user object>
	private HashMap<String, User> myPassword;	
	private HashSet<User> followers = null;
	private HashSet<User> feeders = null;
	String username, password, f, fname, lname, following;
	private User user;
	User currentUser;
	
	// movie parsing
	private HashMap<String, HashSet<String>> allActorsMovies = new HashMap<String, HashSet<String>>();	// actors mapped to set of movies
	private HashMap<String, HashSet<String>> allMoviesByGenre = new HashMap<String, HashSet<String>>();	// genres mapped to set of movies 
	@SuppressWarnings("unused")
	private Movie myMovie;
	private HashSet<String> actorSet = new HashSet<String>();
	private HashSet<String> titleSet = new HashSet<String>();
	private HashSet<String> genreSet = new HashSet<String>();
	
	// event parsing
	private Event event;
	String action, movie, rating;
	private HashMap<String, Event> userEvent;
	private HashSet<String> eventSet = new HashSet<String>();
	private HashMap<String, HashSet<String>> eventsByUser = new HashMap<String, HashSet<String>>();
	
	
	public HashMap<String, User> getUserMap() {
		return myUsername;
	}
	
	public HashMap<String, User> getUserMap2() {
		return myPassword;
	}
	
	public HashMap<String, Event> getEvent() {
		return userEvent;
	}
	
	
public void parseUsers() {		
		
		try {
			File inputFile = new File("a1testfile.txt");
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	      	        
	        NodeList nListUser = doc.getElementsByTagName("user");	       
	        for (int temp = 0; temp < nListUser.getLength(); temp++) {	
	        	
	        	Node user1 = nListUser.item(temp);	
	        	if (user1.getNodeType() == Node.ELEMENT_NODE) {
	        		Element myUser = (Element) user1;	            	
	    	        
	        		// parse user info
	        		String username = myUser.getElementsByTagName("username").item(0).getTextContent().trim();
	        		String password = myUser.getElementsByTagName("password").item(0).getTextContent().trim();
	        		String fname = myUser.getElementsByTagName("fname").item(0).getTextContent().trim();
	        		String lname = myUser.getElementsByTagName("lname").item(0).getTextContent().trim();	        		
	        		String following = myUser.getElementsByTagName("following").item(0).getTextContent().trim(); 
//	        		String feed = myUser.getElementsByTagName("feed").item(0).getTextContent().trim(); 	        		
	        		
	        		
	        		String[] parts = following.split("\\s+");
	        		
	        		HashSet<String> followingSet = new HashSet<String>();
	        		for (String follower: parts) {
//	        			System.out.println("Follower: "+follower);	        			
	        			followingSet.add(follower);
	        		}
	        		
	        		// store user info
	        		user = new User(username, password, fname, lname, followingSet);
	        		myUsername.put(username, user);	      
	        		myPassword.put(password, user);
      		
	        		NodeList nListEvent = doc.getElementsByTagName("feed");	
        		
			        for (int temp2 = 0; temp2 < 1; temp2++) {	
//						System.out.println("feed"+nListEvent.getLength()+"temp2"+temp2);				        	
			        	Node eventNode = nListEvent.item(temp2);	
			        	if (eventNode.getNodeType() == Node.ELEMENT_NODE) {
			        		Element myEvent = (Element) eventNode;	            	
			    	        
			        		if (myEvent.getElementsByTagName("action").getLength() > 0) {
			        			// parse event info
				        		String action = myEvent.getElementsByTagName("action").item(0).getTextContent().trim();
				        		String movie = myEvent.getElementsByTagName("movie").item(0).getTextContent().trim();
				        		String rating = myEvent.getElementsByTagName("rating").item(0).getTextContent().trim();
								
				        		String[] parts2 = action.split("\\r?\\n");
				        		HashSet<String> feedSet = new HashSet<String>();
				        		for (String feeder: parts2) {
//				        			System.out.println("Feeder: "+feeder);		        			
				        			feedSet.add(feeder);
				        		}
				        		String[] parts3 = movie.split("\\r?\\n");
				        		HashSet<String> feedSet2 = new HashSet<String>();
				        		for (String feeder: parts3) {
//				        			System.out.println("Feeder: "+feeder);		        			
				        			feedSet2.add(feeder);
				        		}	
				        		String[] parts4 = rating.split("\\r?\\n");
				        		HashSet<String> feedSet3 = new HashSet<String>();
				        		for (String feeder: parts4) {
//				        			System.out.println("Feeder: "+feeder);		        			
				        			feedSet3.add(feeder);
				        		}	
				        		// store event info
				        		event = new Event(username, feedSet, feedSet2, feedSet3);
				        		userEvent.put(username, event);
				        		
				        		
//				        		// store event info
//				        		event = new Event(username, action, movie, rating);
//				        		userEvent.put(username, event);
			        		
				        		String thisEvent = username + " " + action.toLowerCase() + " the movie '" + movie + "'.";
				        		eventSet.add(thisEvent);
				        		
//				        		if (eventsByUser == null) {
//				        			eventsByUser = new HashMap<String, HashSet<String>>();
//				    			}
				        		
				        		for (String thisUser: eventSet) {        					        					        				
				        			if (eventsByUser.containsKey(thisUser)) {
				        				eventsByUser.get(thisUser).add(thisEvent);
				        			}
				        			else {
				        				HashSet<String> setOfEvents = new HashSet<String>();
				        				setOfEvents.add(thisEvent);
				        				eventsByUser.put(thisUser, setOfEvents);
				        			}
				        		}
			        		}
			        	}
			        }
	        	}        	
	        }
    		// store who follows who	        		
    		if (followers == null) {
    			followers = new HashSet<User>();
			}
    		if (feeders == null) {
    			feeders = new HashSet<User>();
			}    		
    		for (User user : myUsername.values()) {
    			for (String followerName: user.f) {
    				myUsername.get(followerName).followers.add(user.username);
    			}
//    			for (String feederName: user.f2) {
//    				myUsername.get(feederName).feeders.addAll(user.f2);
//    			}   			
    		}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void parseMovies() {
		
		try {
			File inputFile = new File("a1testfile.txt");
	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	        Document doc = dBuilder.parse(inputFile);
	        doc.getDocumentElement().normalize();
	        
	        NodeList nListMovie = doc.getElementsByTagName("movie");	
	        for (int temp = 0; temp < nListMovie.getLength(); temp++) {	         
	        	Node movie1 = nListMovie.item(temp);	
	        	if (movie1.getNodeType() == Node.ELEMENT_NODE) {
	        		Element thisMovie = (Element) movie1;	

	        		if (thisMovie.getElementsByTagName("title").getLength() > 0) {
	        		
		        		// parse movie info
		        		String title = thisMovie.getElementsByTagName("title").item(0).getTextContent().trim();
		        		String director = thisMovie.getElementsByTagName("director").item(0).getTextContent().trim();
		        		String writers = thisMovie.getElementsByTagName("writers").item(0).getTextContent().trim();
		        		String year = thisMovie.getElementsByTagName("year").item(0).getTextContent().trim();
		        		String genre = thisMovie.getElementsByTagName("genre").item(0).getTextContent().trim();
		        		String description = thisMovie.getElementsByTagName("description").item(0).getTextContent().trim();
		        		String rating = thisMovie.getElementsByTagName("rating").item(0).getTextContent().trim();
		        		String actors = thisMovie.getElementsByTagName("actors").item(0).getTextContent().trim();		        	
		        		
		        		// store movie info
		        		myMovie = new Movie(title, director, writers, year, genre, description, rating);
		        		
		        		// actor search
		        		if (actorSet == null) {
		        			actorSet = new HashSet<String>();
		    			}
		        		
		        		String[] parts = actors.split("(?<!\\G\\S+)\\s");		        		
		        		for (String actor: parts) {        		
		        			actorSet.add(actor);		        				
		        			if (allActorsMovies.containsKey(actor)) {
		        				allActorsMovies.get(actor).add(title);
		        			}
		        			else {
		        				HashSet<String> titles = new HashSet<String>();
		        				titles.add(title);
		        				allActorsMovies.put(actor, titles);
		        			}
		        		}
		        		
		        		// title search
		        		String[] parts2 = title.split("\\r?\\n");		        		
		        		for (String titles: parts2) {        		
		        			titleSet.add(titles);
		        		}
		        		
		        		
		        		// genre search
		        		if (genreSet == null) {
		        			genreSet = new HashSet<String>();
		    			}
		        		
		        		String[] parts3 = genre.split("(?<!\\G\\S+)\\s");		        		
		        		for (String genres: parts3) {        		
		        			genreSet.add(genres);		        				
		        			if (allMoviesByGenre.containsKey(genres)) {
		        				allMoviesByGenre.get(genres).add(title);
		        			}
		        			else {
		        				HashSet<String> titles = new HashSet<String>();
		        				titles.add(title);
		        				allMoviesByGenre.put(genres, titles);
		        			}
		        		}		        
		        	}
		        }  
	        }
		} catch (Exception e) {
			e.printStackTrace();
		}		
	}
	
//	public void parseEvents() {		
//		
//		try {
//			File inputFile = new File("a1testfile.txt");
//	        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
//	        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
//	        Document doc = dBuilder.parse(inputFile);
//	        doc.getDocumentElement().normalize();
//	        
//	        
//		} catch (Exception e) {
//		e.printStackTrace();
//		}	
//	}
	
	
	
	public void userSearch() {
		
		try {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			System.out.println("Please enter the username you are searching for.");
			String thisUsername = br.readLine(); 		
			
			if (myUsername.containsKey(thisUsername)) {
				System.out.println("1 result: ");
				System.out.println(thisUsername + "\n");
				 
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
			else {
				System.out.println("0 results.");
				 
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void actorSearch() {
		
		try {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			System.out.println("Please enter the name of the actor you wish to search by.");
			String thisActor = br.readLine(); 
			
			if (actorSet.contains(thisActor)) {
				
				HashSet<String> movieTitlesForActor = allActorsMovies.get(thisActor);	
				System.out.println(movieTitlesForActor.size() + " result(s): ");
				
				for (String title: movieTitlesForActor) {
					System.out.println("'" + title + "'" + "\n");
				}				
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
			else {
				System.out.println("0 results.");
				 
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void titleSearch() {
	
		try {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			System.out.println("Please enter the title you wish to search by.");
			String thisTitle = br.readLine(); 
			
			if (titleSet.contains(thisTitle)) {
				System.out.println("1 result: ");
				System.out.println("'" + thisTitle + "'" + "\n");
				
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
			else {
				System.out.println("0 results.");
				 
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void genreSearch() {
	
		try {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			System.out.println("Please enter the genre you wish to search by.");
			String thisGenre = br.readLine(); 
			
			if (genreSet.contains(thisGenre)) {
				
				HashSet<String> movieTitlesForGenre = allMoviesByGenre.get(thisGenre);	
				System.out.println(movieTitlesForGenre.size() + " result(s): ");
					
					for (String title: movieTitlesForGenre) {
						System.out.println("'" + title + "'");
					}
					System.out.println();
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
			else {
				System.out.println("0 results.");
				 
				SearchMenu menu = new SearchMenu();
				menu.searchMenu();
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
