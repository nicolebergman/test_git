package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class BigMenu {
	
	
	User currentUser;
	Event usersEvent;
	
	private BufferedReader br = null;
	
	public void bigMenu(User user, Parser parser, Event event) {
	
		currentUser = user;
		usersEvent = event;
		

		try {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
				
				// menu options 1-6
				System.out.print("\n1. Search Users");
			    System.out.print("\n2. Search Movies");
			    System.out.print("\n3. View Feed");
			    System.out.print("\n4. View Profile");
			    System.out.print("\n5. Logout");
			    System.out.print("\n6. Exit\n");
			    
			    int nextAction = Integer.parseInt(br.readLine());
				
			    if (nextAction == 1) {		// search users
			    	parser.userSearch();
			    }
			    else if (nextAction == 2) {	// search movies
			    	String t = "", d = "", w = "", y = "", g = "", de = "", r = "";
			    	Movie menu = new Movie(t, d, w, y, g, de, r);
			    	menu.movieMenu();
			    	
			    }
			    else if (nextAction == 3) {	// view feed
			    	event.userFeed();
			    }
			    else if (nextAction == 4) {	// view profile
			    	user.userProfile();
			    }
			    else if (nextAction == 5) {	// logout
			    	String filename = "";
			    	MainMenu main = new MainMenu(filename);
			    	main.mainMenu();
			    }
			    else if (nextAction == 6) {	// exit
			    	System.exit(1);
			    }
			    else  {
			    	System.out.print("You have entered an invalid command, please try again.");
			    	bigMenu(user, parser, event);
			    }  
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
		} catch(NumberFormatException e) {
            System.out.print("You have entered an invalid command, please try again.");	    	  
            bigMenu(user, parser, event);
        }			
	}
}