package njbergma_CSCI201_Assignment1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class SearchMenu {
	
	private BufferedReader br = null;
	private Parser parser;
	private User currentUser;
	private Event usersEvent;
	
	public SearchMenu() {
		
	}


	public void searchMenu() {
		
		try  {
			
			if (br == null) {
				br = new BufferedReader(new InputStreamReader(System.in));
			}
			
			int trip = 0;
			while (trip == 0) {
				
				System.out.println("Please choose from the following options: ");
				System.out.println("1. Back to Login Menu");
				System.out.println("2. Search Again");
				
				int action = Integer.parseInt(br.readLine());
				if (action == 1) {
					trip = 1;	
				
					BigMenu bm = new BigMenu();				
					bm.bigMenu(currentUser, parser, usersEvent);	
				}

				else if (action == 2) {
					trip = 1;
					String filename = "";
					Parser parse = new Parser(filename);
			    	parse.userSearch();
				}
				else {
					System.out.println("Invalid input. Try again.\n");
					// loop menu
					trip = 0;
					searchMenu();
				}
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(NumberFormatException e) {
	    	  System.out.print("You have entered an invalid command, please try again.\n");	    	  
	    	  searchMenu();
        }			
		
	}
	
}
