package njbergma_CSCI201_Assignment1;

import java.util.*;

public class User {
	

	String username, password, firstName, lastName;
	String u, filename;
	HashSet<String> followers = new HashSet<String>();
	HashSet<String> feeders = new HashSet<String>();	
	Set<String> f;	// followingSet
	
	
	User(String u, String p, String fname, String lname, Set<String> followingSet) {
		username = u;
		password = p;
		firstName = fname;
		lastName = lname;
		f = followingSet;
	}

	public void userProfile() {
		char ch; 
		String pass="";
		for(int i=0; i<password.length(); i++) {
			ch = password.charAt(i);
			if (i>0 && i<password.length()-1) ch='*';
			pass = pass + ch;
		}

		System.out.println(firstName + " " + lastName);
		System.out.println("Username: " + username);
		System.out.println("Password: " + pass);
		
		// print following
		System.out.println("Following: ");		
		for (String s: f) {
			System.out.println("\t" + s);
		}
		
		// print followers
		System.out.println("Followers: ");
		for (String username: followers) {
			System.out.println("\t" + username);
		}
		
		GoBackMenu back = new GoBackMenu();
		back.goBack();	
	}	
	
}
